# SmartBrain - v2
Final project for ZTM course

1. Clone this repo
2. Run `npm install`
3. Run `npm start`
